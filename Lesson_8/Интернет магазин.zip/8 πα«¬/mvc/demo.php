<?=$_COOKIE['fio'];?>
