<?
$today = date("d.m.Y");

$title = "Contacts...";
$content = "templates/contact.php";



include "templates/main.php";//базовый шаблон